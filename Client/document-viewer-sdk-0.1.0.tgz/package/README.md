# react-pdf-sdk

A high-performance React PDF viewer SDK built on [PDF.js](https://mozilla.github.io/pdf.js/). Drop it into any React 18+ app.

## Install

```bash
npm install react-pdf-sdk pdfjs-dist
```

## Quick start

```tsx
import { PDFViewer } from "react-pdf-sdk";
import "react-pdf-sdk/dist/styles.css";

export default function App() {
  return (
    <div style={{ height: "100vh" }}>
      <PDFViewer src="/my-document.pdf" />
    </div>
  );
}
```

## Component API

### `<PDFViewer>`

| Prop | Type | Default | Description |
|---|---|---|---|
| `src` | `PDFSource` | **required** | URL, `ArrayBuffer`, `Uint8Array`, or `{ url, httpHeaders }` |
| `initialPage` | `number` | `1` | Starting page (uncontrolled) |
| `page` | `number` | — | Controlled current page |
| `zoom` | `ZoomMode` | `"fit-width"` | `"fit-width"` \| `"fit-page"` \| `"actual-size"` \| `number` |
| `layout` | `"single" \| "continuous" \| "double"` | `"continuous"` | Page layout |
| `rotation` | `0 \| 90 \| 180 \| 270` | `0` | Page rotation |
| `toolbar` | `boolean \| ToolbarConfig` | `true` | Show/configure toolbar |
| `thumbnails` | `boolean` | `false` | Show thumbnail sidebar |
| `darkMode` | `boolean` | `false` | Dark rendering |
| `password` | `string` | — | Password for encrypted PDFs |
| `className` | `string` | — | Extra class on root element |
| `style` | `CSSProperties` | — | Inline styles on root element |
| `onLoad` | `(info: PDFDocumentInfo) => void` | — | Fires when document loads |
| `onError` | `(err: PDFLoadError) => void` | — | Fires on load failure |
| `onPageChange` | `(page, total) => void` | — | Fires on visible page change |
| `onZoomChange` | `(zoom: number) => void` | — | Fires on zoom change |
| `onRotationChange` | `(rotation) => void` | — | Fires on rotation change |

### Toolbar config

```ts
interface ToolbarConfig {
  navigation?: boolean;  // page prev/next + input
  zoom?: boolean;        // zoom in/out + select
  rotate?: boolean;      // rotate clockwise button
  download?: boolean;    // download button (default: false)
  print?: boolean;       // print button (default: false)
  search?: boolean;      // search bar
  rightSlot?: ReactNode; // custom JSX in right toolbar area
}
```

## Imperative API (ref)

```tsx
import { useRef } from "react";
import { PDFViewer, PDFViewerHandle } from "react-pdf-sdk";

function App() {
  const viewerRef = useRef<PDFViewerHandle>(null);

  return (
    <>
      <button onClick={() => viewerRef.current?.goToPage(5)}>Go to page 5</button>
      <button onClick={() => viewerRef.current?.setZoom(1.5)}>150%</button>
      <button onClick={() => viewerRef.current?.download()}>Download</button>
      <PDFViewer ref={viewerRef} src="/doc.pdf" />
    </>
  );
}
```

### `PDFViewerHandle` methods

| Method | Signature | Description |
|---|---|---|
| `goToPage` | `(page: number) => void` | Navigate to page |
| `nextPage` | `() => void` | Next page |
| `prevPage` | `() => void` | Previous page |
| `setZoom` | `(zoom: ZoomMode) => void` | Set zoom |
| `rotate` | `() => void` | Rotate clockwise by 90° |
| `download` | `() => void` | Trigger download |
| `print` | `() => void` | Trigger print dialog |
| `getDocumentInfo` | `() => PDFDocumentInfo \| null` | Get document metadata |
| `search` | `(query: string) => Promise<number>` | Search text, returns match count |
| `clearSearch` | `() => void` | Clear search highlights |

## Bookmarks & highlights

Highlights are rendered on the document and listed in the bookmarks sidebar. Pass them via the `bookmarks` prop and receive mutations via `onBookmarksChange`.

```tsx
const [bookmarks, setBookmarks] = useState([]);

<DocumentViewer
  src={file}
  bookmarks={bookmarks}
  onBookmarksChange={setBookmarks}
/>
```

### HighlightRange fields

```ts
type HighlightRange = {
  id: string;                    // unique identifier
  text: string;                  // selected text content
  username?: string;            // optional username shown in the sidebar
  locked?: boolean;              // read-only in the sidebar UI
  comment?: string;              // optional annotation shown in the sidebar
  pageNumber?: number;           // page the highlight lives on (PDF / TIFF)
  bookmarkBottomLeft?: string;   // sidebar label, bottom-left  (default: "")
  bookmarkBottomRight?: string;  // sidebar label, bottom-right (default: "Manual")

  // PDF / image viewers — pixel coordinates on the rendered page canvas
  position?: { x: number; y: number; width: number; height: number };

  // Text-based viewers (Docx, Text, Spreadsheet, HTML) — character offsets
  textPosition?: { start: number; end: number };
}
```

### PDF example

```tsx
bookmarks={[{
  id: "hl-1",
  text: "speculates that the patent",
  username: "Alex Chen",
  locked: true,
  comment: "Review with legal team",
  pageNumber: 2,
  position: { x: 120, y: 340, width: 280, height: 18 },
}]}
```

`position` coordinates are in pixels at the rendered scale, measured from the top-left of the page canvas.

### Text-based viewer example (Docx, Text, Spreadsheet, HTML)

```tsx
bookmarks={[{
  id: "hl-2",
  text: "Andreas Gal",
  username: "Morgan Lee",
  comment: "Co-inventor",
  textPosition: { start: 450, end: 461 },
}]}
```

`textPosition` offsets are character positions within the rendered document text. The easiest way to get valid values is to let the user highlight interactively, then persist the objects returned by `onBookmarksChange` — they include all the fields needed to restore the highlight on next load.

### Persisting and restoring highlights

```tsx
// Save
const saved = exportHighlights(bookmarks); // JSON string
localStorage.setItem("highlights", saved);

// Restore
const restored = JSON.parse(localStorage.getItem("highlights") ?? "[]");
<DocumentViewer src={file} bookmarks={restored} onBookmarksChange={setBookmarks} />
```

When `locked: true` is set, the sidebar hides the edit pencil and the item becomes read-only.

### Sidebar-only (no document highlight)

To show an entry in the sidebar without a document highlight — for example a chapter link — omit `position` and `textPosition` and set `bookmarkBottomRight` to label it:

```tsx
bookmarks={[{
  id: "ch-1",
  text: "Chapter 3 — Results",
  pageNumber: 12,
  bookmarkBottomRight: "Chapter",
}]}
```

## Hooks

### `usePDFDocument`

```tsx
import { usePDFDocument } from "react-pdf-sdk";

function MyComponent() {
  const { isLoading, error, info, totalPages, pdfDoc } = usePDFDocument({
    src: "/doc.pdf",
    onLoad: (info) => console.log("Loaded", info.totalPages, "pages"),
  });
}
```

## Controlled mode

```tsx
const [page, setPage] = useState(1);

<PDFViewer
  src="/doc.pdf"
  page={page}
  onPageChange={(p) => setPage(p)}
/>
```

## Custom toolbar slot

```tsx
<PDFViewer
  src="/doc.pdf"
  toolbar={{
    rightSlot: <button onClick={handleShare}>Share</button>,
  }}
/>
```

## Worker configuration

By default the PDF.js worker is loaded from cdnjs. Override for self-hosting:

```tsx
import { configureWorker } from "react-pdf-sdk";

configureWorker("/static/pdf.worker.min.mjs");
```

## Styling & theming

Override CSS custom properties on the root:

```css
.my-viewer {
  --rpdf-accent: #ff6b00;
  --rpdf-toolbar-bg: #1e1e2e;
  --rpdf-bg: #13131f;
}
```

```tsx
<PDFViewer src="/doc.pdf" className="my-viewer" />
```

## Building

```bash
npm run build   # → dist/index.js (ESM) + dist/index.cjs (CJS) + dist/index.d.ts
npm run dev     # dev server with sandbox app
```

`npm run build` keeps source maps in `dist/` for local debugging.

## Packaging

Use the standard npm pack/publish flow:

```bash
npm pack
```

When packaging:

- `prepack` runs `npm run build:pack`
- `build:pack` builds the library with `BUILD_SOURCEMAP=false`
- the generated tarball excludes `.map` files
- `postpack` runs `npm run build` to restore the normal map-enabled `dist/`

If you want to generate the package-ready output without creating a tarball:

```bash
npm run build:pack
```
